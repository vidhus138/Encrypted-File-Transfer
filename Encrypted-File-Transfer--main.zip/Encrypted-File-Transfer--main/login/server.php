<html>
<style>
.logoutLblPos{

   position:fixed;
   right:10px;
   top:5px;
}
</style>
<title>Server </title>
<link rel="stylesheet" href="css/style.css" />
<body >
<form align="right" name="form1" method="post" action="index.php">
  <label class="logoutLblPos">
  <input name="submit2" type="submit" id="submit2" value="back">
  </label>
</form>
<center>
<h1 style="font-size:200%;" >SERVER SIDE</h1>
<h2>Click on image to start the server </h2>

<table border="1"  width="50%" Height="50%">
<tr>

<th width="5%">Server </th>
</tr>
<tr>
<td>
<center>
<a href="runServer.bat" target="_blank"><img src="server1.jpg" alt="example" width="200" Height="200" ></a>
</center>
</td>

</tr>

</html>
