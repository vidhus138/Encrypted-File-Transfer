public class Main {
    public static void main(String[] args)
    {
        //creating object of RegistrationForm class
        new RegistrationForm();
    }
}